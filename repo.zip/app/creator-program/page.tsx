export default function CreatorProgramPage() {
  return (
    <section className="container py-16">
      <h1 className="text-3xl font-extrabold tracking-tight">Creator Program</h1>
      <p className="mt-3 opacity-80">This is a placeholder page for Creator Program. Replace with real content later.</p>
    </section>
  );
}

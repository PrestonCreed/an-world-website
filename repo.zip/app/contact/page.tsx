export default function ContactPage() {
  return (
    <section className="container py-16">
      <h1 className="text-3xl font-extrabold tracking-tight">Contact</h1>
      <p className="mt-3 opacity-80">This is a placeholder page for Contact. Replace with real content later.</p>
    </section>
  );
}
